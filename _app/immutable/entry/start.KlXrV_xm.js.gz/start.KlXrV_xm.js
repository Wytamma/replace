import{a as t}from"../chunks/entry.RB64J3A7.js";export{t as start};
