import{a as t}from"../chunks/entry.BnjAZMSo.js";export{t as start};
