import{a as t}from"../chunks/entry.Dx-XMN6B.js";export{t as start};
